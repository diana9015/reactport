import React from 'react';

function Visual() {
	return (
		<div>
			<div className='visual'>
				<div className='inner'>
					<h2>Lorem, ipsum</h2>
					<p>
						Lorem ipsum dolor sit, amet consectetur adipisicing elit. Autem
						minus
						<br />
						facere, beatae pariatur magni eligendi consequatur doloribus. Iusto
						modi quae nostrum reiciendis ab iure, culpa sunt accusantium beatae
						vero soluta.
					</p>
					<a href='#'>LEARN MORE</a>
				</div>
			</div>
		</div>
	);
}

export default Visual;
