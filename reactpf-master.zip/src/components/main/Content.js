import React from 'react';

function Content() {
	return <div>content</div>;
}

export default Content;
