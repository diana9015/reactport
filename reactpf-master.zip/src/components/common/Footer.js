import React from 'react';

function Footer() {
	return <figure id='visual'></figure>;
}

export default Footer;
