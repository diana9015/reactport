import React from 'react';

function Aboutus() {
	return <div>aboutus</div>;
}

export default Aboutus;
