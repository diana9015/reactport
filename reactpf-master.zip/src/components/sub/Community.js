import React from 'react';

function Community() {
	return <div>community</div>;
}

export default Community;
