import React from 'react';

function Join() {
	return <div>join</div>;
}

export default Join;
